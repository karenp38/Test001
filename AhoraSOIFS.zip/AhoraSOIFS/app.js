// Initialize Cloud Firestore through Firebase
firebase.initializeApp({
    apiKey: "AIzaSyCkFGMriATVkiEDHkcK5QgGYePPlGZ6nUo",
    authDomain: "ahora-soi-911.firebaseapp.com",
    projectId: "ahora-soi-911"
});

var db = firebase.firestore();


//Agregar documentos


//Leer documentos
var tabla = document.getElementById('tabla');
db.collection("services").onSnapshot((querySnapshot) => {
    tabla.innerHTML = '';
    querySnapshot.forEach(async (doc) => {

        var pago = doc.data().paid;
        if (pago !== true) {
            pago = 'Sin confirmar pago';
        } else {
            pago = 'Confirmado';
        }
        var nombrepaciente = '';
        var nombredoctor = '';
        //Revisar paciente
        var snapshot = await db.collection("patients").doc(doc.data().patientId).get();
        var patient = snapshot.data();
        nombrepaciente = `${patient.names} ${patient.lastNames}`;

        if(doc.data().doctorId!=null)
        {
        var snapshotDoctor = await db.collection("doctors").doc(doc.data().doctorId).get();
        var doctor = snapshotDoctor.data();
        nombredoctor = `${doctor.fullName}`;
        }
        else {
          nombredoctor="Por aceptar cita";
        }
        //Fin Revisar

        tabla.innerHTML += `
        <tr>
          <th scope="row">${nombrepaciente}</th>
          <td>
          ${nombredoctor}</td>
          <td>
          ${doc.data().address.description}</td>
          <td>${pago}</td>
          <td>${doc.data().paymentWay}</td>
          <td><button class="btn btn-warning" onclick="editar('${doc.id}','${doc.data().paid}','${doc.data().paymentWay}')">Editar</button></td>
        </tr>
        `
    });
});


//Borrar Datos
function eliminar(id) {
    tabla.innerHTML = '';
    db.collection("users").doc(id).delete().then(function () {
        console.log("Documento eliminado!");

    }).catch(function (error) {
        console.error("Error removing document: ", error);
    });
}

//Borrar Datos
function editar(id, paid, way) {


    var washingtonRef = db.collection("services").doc(id);
    document.getElementById('formaPago').value = way;

    var boton = document.getElementById('boton');
    boton.innerHTML = 'Editar';

    boton.onclick = function () {
        var formaPago = document.getElementById('formaPago').value;
        var pagado = document.getElementById('pagado').value;

        // Set the "capital" field of the city 'DC'
        return washingtonRef.update({
            paid: true,
            paymentway: formaPago
        })
            .then(function () {
                console.log("Document successfully updated!");
                boton.innerHTML = 'Guardar';


            })
            .catch(function (error) {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
    }
}
