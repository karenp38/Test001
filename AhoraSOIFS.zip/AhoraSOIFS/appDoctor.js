// Initialize Cloud Firestore through Firebase
firebase.initializeApp({
    apiKey: "AIzaSyCkFGMriATVkiEDHkcK5QgGYePPlGZ6nUo",
    authDomain: "ahora-soi-911.firebaseapp.com",
    projectId: "ahora-soi-911"
});

var db = firebase.firestore();


//Agregar documentos
function guardar()
{

  var nombre=document.getElementById('nombres').value;
  var apellido=document.getElementById('apellidos').value;
  var telefono=document.getElementById('telefono').value;
  var email=document.getElementById('email').value;
  alert(email)
  db.collection("doctors").add({
      Email: email ,
      names: nombre,
      lastNames: apellido,
      fullName:nombre+apellido,
      phoneNumber:telefono
  })
  .then(function(docRef) {
      console.log("Document written with ID: ", docRef.id);
      document.getElementById('nombres').value='';
      document.getElementById('apellidos').value='';
      document.getElementById('telefono').value='';
      document.getElementById('email').value='';
  })
  .catch(function(error) {
      console.error("Error adding document: ", error);
  });
}


//Leer documentos
var tabla = document.getElementById('tabla');
db.collection("doctors").onSnapshot((querySnapshot) => {
    tabla.innerHTML = '';
    querySnapshot.forEach(async (doc) => {
        tabla.innerHTML += `
        <tr>
          <th scope="row">${doc.data().names}</th>
          <td>
          ${doc.data().lastNames}</td>
          <td>
          ${doc.data().email}</td>
          <td>${doc.data().phoneNumber}</td>
          <td><button class="btn btn-danger" onclick="eliminar('${doc.id}')">Eliminar</button></td>
          <td><button class="btn btn-warning" onclick="editar('${doc.id}','${doc.data().paid}','${doc.data().paymentWay}')">Editar</button></td>
        </tr>
        `
    });
});


//Borrar Datos
function eliminar(id) {
    tabla.innerHTML = '';
    db.collection("users").doc(id).delete().then(function () {
        console.log("Documento eliminado!");

    }).catch(function (error) {
        console.error("Error removing document: ", error);
    });
}

//Borrar Datos
function editar(id, paid, way) {


    var washingtonRef = db.collection("services").doc(id);
    document.getElementById('formaPago').value = way;

    var boton = document.getElementById('boton');
    boton.innerHTML = 'Editar';

    boton.onclick = function () {
        var formaPago = document.getElementById('formaPago').value;
        var pagado = document.getElementById('pagado').value;

        // Set the "capital" field of the city 'DC'
        return washingtonRef.update({
            paid: true,
            paymentway: formaPago
        })
            .then(function () {
                console.log("Document successfully updated!");
                boton.innerHTML = 'Guardar';


            })
            .catch(function (error) {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
    }
}
